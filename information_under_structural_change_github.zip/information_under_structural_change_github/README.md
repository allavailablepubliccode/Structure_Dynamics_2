# Preserving Information under Structural Change in the Human Connectome

Code and derived data for reproducing the computational analyses reported in the manuscript.

## What is included

The repository contains a complete reconstruction of the analysis pipeline used in the paper:

1. aggregate the 1064 BrainGraph/HCP GraphML connectomes into a 68-region cortical group connectome;
2. compute group cortical coordinates;
3. construct the structural-change matrix used in the primary analysis;
4. construct the stationary multivariate Ornstein–Uhlenbeck model and baseline conditional mutual information (CMI) vector;
5. reproduce the primary rate analysis;
6. reproduce the structural-pattern robustness analysis; and
7. reproduce the fixed-total-adaptive-capacity control.

The original early preprocessing source file was not retained. `01_build_group_connectome.py` was therefore reconstructed from the archived raw GraphML files and archived derived arrays. It was validated against the archived group data: prevalence, mean streamline counts, final group connectivity, gain vector, noise vector, and global coupling are reproduced exactly. The reconstructed structural model agrees with the archived model to floating-point precision for all quantities used in the manuscript analyses.

## Files

- `01_build_group_connectome.py` — raw BrainGraph/HCP GraphML -> group connectivity and group coordinates.
- `02_build_model.py` — group data -> structural-change model and baseline OU/CMI model.
- `03_main_analysis.py` — primary `N = 5, 10, 20, 40` analysis.
- `04_structural_pattern_robustness.py` — Primary, Proportional, Distance-dependent, and Matching-index-dependent perturbations.
- `05_fixed_total_capacity_control.py` — fixed cumulative adaptive capacity for `N = 5` and `N = 20`.
- `model_utils.py` — OU, covariance, CMI, Jacobian, and bounded-adaptation utilities.
- `verify_reconstruction.py` — numerical comparison with the archived reference model.

`data/derived/` contains the small group-level empirical inputs used by the analysis. `data/reference/` contains archived model files retained solely as numerical reference checkpoints. `results/reference/` contains the archived summary outputs underlying Table 1.

## Environment

Python 3.11+ is recommended.

```bash
python -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
```

## Rebuild the group connectome from the public GraphML archive

Download the BrainGraph/HCP `repeated_10_scale_33` archive described in the manuscript Data Availability statement. If the archive is named `raw.zip`:

```bash
python 01_build_group_connectome.py raw.zip --output-dir data/derived
```

The archived dataset used here contained 1064 subject GraphML files. Cortical nodes are identified from the GraphML `dn_region` field and ordered by atlas order. For each edge,

`expected streamline count = prevalence across subjects x mean number of fibers when present`.

All edges with nonzero prevalence are retained; no 50% prevalence threshold is applied. Expected streamline counts are transformed with `log(1+w)` and the resulting matrix is divided by its spectral radius. A fixed random seed (`20260907`) generates regional gain and noise heterogeneity.

## Build the manuscript model

```bash
python 02_build_model.py \
  --consensus data/derived/hcp86_empirical_consensus.npz \
  --coordinates data/derived/hcp68_group_coordinates.csv \
  --output-dir data/generated
```

The primary structural perturbation is

`DeltaW_ij = 0.2 * W0_ij * Q_ij`,

where, on existing edges,

`Q_ij proportional to (M_ij + 0.05) * exp(-D_ij/d_med)`

and `Q` is normalized to have mean 1 over existing directed edges. This is equivalent to the manuscript proportional form. For the archived data, the resulting proportionality coefficient multiplying `W0_ij (M_ij+0.05) exp(-D_ij/d_med)` is approximately `0.8019055425568947`.

The OU system matrix is

`A = c diag(g) W - diag(theta)`

with baseline `theta_i = 1`. The global coupling is chosen so that the leading real eigenvalue of `c diag(g) W0` is `0.72`, yielding a baseline leading real eigenvalue of `A` of approximately `-0.28`.

## Verify model reconstruction

After rebuilding the data/model:

```bash
python verify_reconstruction.py
```

The comparison deliberately ignores the archived `theta_final` field in the old structural-model file because that field came from an earlier exploratory run and is not used by any manuscript analysis.

## Reproduce the manuscript analyses

Primary analysis:

```bash
python 03_main_analysis.py
```

Structural-pattern robustness:

```bash
python 04_structural_pattern_robustness.py
```

Fixed-total-adaptive-capacity control:

```bash
python 05_fixed_total_capacity_control.py
```

These analyses are computationally expensive because the CMI Jacobian with respect to all 68 damping parameters is repeatedly evaluated analytically through the OU covariance solution. Runtime therefore depends strongly on the machine and linear-algebra backend.

## Reference values from Table 1

For the primary structural-change pattern, the archived calculations gave:

| N | Endpoint E | Fractional compensation K | Integrated error | Stability margin m |
|---:|---:|---:|---:|---:|
| 5 | 6.41094 | 0.10410 | 1.92354 | 0.07636 |
| 10 | 5.77997 | 0.19227 | 1.77706 | 0.08363 |
| 20 | 4.76926 | 0.33352 | 1.55771 | 0.09819 |
| 40 | 3.38597 | 0.52682 | 1.22261 | 0.12729 |

In the fixed-total-capacity control, `N=5` and `N=20` both gave endpoint `E ≈ 5.77997` and `K ≈ 0.19227` (minor last-digit differences reflect numerical solver tolerance).

The complete archived summary tables are in `results/reference/`.

## Notes on terminology

`N` controls how the same total structural change is divided before successive opportunities for dynamical adaptation. It should therefore be interpreted as structural change relative to adaptive opportunity, not as a calibrated physical time unit.

## Data source

The individual connectomes are from the public BrainGraph/Human Connectome Project dataset identified in the manuscript. Please cite the original data source according to its terms when reusing the data.
